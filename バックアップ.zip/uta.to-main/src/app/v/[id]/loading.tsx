export default function Loading() {
  return <div className="p-4 text-sm opacity-70">読み込み中…</div>;
}
