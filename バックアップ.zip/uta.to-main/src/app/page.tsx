export { default } from "./trending/page";
